use_tor = True
use_socks5 = False
socks5_prox = ('addr','port','username','password')

